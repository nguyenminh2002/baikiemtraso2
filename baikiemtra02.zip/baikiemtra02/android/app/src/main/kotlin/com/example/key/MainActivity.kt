package com.example.key

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
