import 'package:flutter/material.dart';

import 'details.dart';

class ListDetails extends StatefulWidget {
  const ListDetails({super.key});

  @override
  State<ListDetails> createState() => _ListDetailsState();
}

class _ListDetailsState extends State<ListDetails>
    with TickerProviderStateMixin {
  FocusNode focusNode = FocusNode();
  final TextEditingController controller = TextEditingController();
  final OutlineInputBorder borderStyle = const OutlineInputBorder(
    borderRadius: BorderRadius.all(Radius.circular(24)),
    borderSide: BorderSide.none,
  );

  final int _index = 0;

  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: const Icon(Icons.menu, color: Colors.black),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 15),
            width: 35,
            child: Image.asset('assets/man.png'),
          ),
        ],
      ),
      body: Center(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          children: <Widget>[
            const Text(
              'Delicious\nfood for you',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),
            Container(
              margin: const EdgeInsets.symmetric(vertical: 15),
              child: TextFormField(
                focusNode: focusNode,
                controller: controller,
                decoration: InputDecoration(
                  hintText: 'Search',
                  prefixIcon: const Icon(
                    Icons.search,
                    color: Colors.black,
                  ),
                  filled: true,
                  fillColor: Colors.black.withOpacity(0.1),
                  border: borderStyle,
                  focusedBorder: borderStyle,
                  disabledBorder: borderStyle,
                  enabledBorder: borderStyle,
                ),
              ),
            ),
            filterWidget(),
            listDetails()
          ],
        ),
      ),
      bottomNavigationBar: TabBar(
        controller: _tabController,
        indicatorColor: Colors.transparent,
        tabs: const <Widget>[
          Tab(
            icon: Icon(Icons.home, color: Colors.deepOrange),
          ),
          Tab(
            icon: Icon(Icons.send, color: Colors.grey),
          ),
          Tab(
            icon: Icon(Icons.shopping_cart, color: Colors.grey),
          ),
          Tab(
            icon: Icon(Icons.history, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget filterWidget() {
    final List<String> filter = ['Foods', 'Drinks', 'Snacks'];
    return SizedBox(
      height: 50,
      width: MediaQuery.of(context).size.width,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemBuilder: (_, index) {
          return Column(
            children: [
              Text(
                filter[index],
                style: TextStyle(
                  color: index == _index ? Colors.deepOrange : Colors.grey,
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 5),
                width: 80,
                height: 2,
                color: index == _index ? Colors.deepOrange : Colors.transparent,
              )
            ],
          );
        },
        itemCount: filter.length,
        separatorBuilder: (_, index) => const SizedBox(width: 8),
      ),
    );
  }

  Widget listDetails() {
    final List<String> image = [
      'https://images.foody.vn/res/g73/726163/prof/s640x400/foody-upload-api-foody-mobile-foody-foood-quan-726-180323104827.jpg',
      'https://media.foody.vn/res/g100001/1000000035/prof/s/file_restaurant_photo_qqzn_16333-1f01100b-211004161013.jpg',
    ];
    final List<String> title = ['Veggie\ntomato mix', 'Spicy sauc'];
    final List<String> subtitle = ['N1,900', 'N2,888'];
    return GestureDetector(
      onTap: ()=>Navigator.of(context).push(MaterialPageRoute(builder: (_)=>Details())),
      child: SizedBox(
        height: 300,
        child: ListView.separated(
          padding: const EdgeInsets.all(10),
          scrollDirection: Axis.horizontal,
          itemBuilder: (_, index) {
            return Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  height: 300,
                  width: 180,
                  padding: const EdgeInsets.only(top: 100),
                  margin: const EdgeInsets.only(top: 40),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                      boxShadow: [
                        const BoxShadow(color: Colors.grey, blurRadius: 4)
                      ]),
                  child: Column(
                    children: [
                      Text(
                        title[index],
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 20,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      Text(
                        subtitle[index],
                        style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                            color: Colors.deepOrange),
                      )
                    ],
                  ),
                ),
                Positioned(
                  top: 0,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(
                        MediaQuery.of(context).size.width / 3),
                    child: SizedBox(
                      height: MediaQuery.of(context).size.width / 3,
                      width: MediaQuery.of(context).size.width / 3,
                      child: Image.network(
                        image[index],
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
          itemCount: image.length,
          separatorBuilder: (_, index) => const SizedBox(width: 8),
        ),
      ),
    );
  }
}
