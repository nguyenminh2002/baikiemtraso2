import 'package:flutter/material.dart';

class Details extends StatelessWidget {
  const Details({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<String> image = [
      'https://images.foody.vn/res/g73/726163/prof/s640x400/foody-upload-api-foody-mobile-foody-foood-quan-726-180323104827.jpg',
    ];
    final List<String> title = ['Veggie\ntomato mix'];
    final List<String> subtitle = ['N1,900'];
    final List<String> titleDetails = ['Details', 'Ingredients'];
    final List<String> contentDetails = [
      'Veggie and tomato mix is the evening  snack during the cold',
      'vegetables, tomatoes etc'
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          Container(
              margin: const EdgeInsets.only(right: 15),
              child: const Icon(
                Icons.favorite_border_sharp,
                color: Colors.black,
              ))
        ],
        leading: InkWell(
            onTap: () => Navigator.pop(context),
            child: const Icon(
              Icons.keyboard_arrow_left_sharp,
              color: Colors.black,
            )),
      ),
      body: ListView(
        shrinkWrap: true,
        children: [
          SizedBox(
            height: 200,
            child: PageView.builder(
              scrollDirection: Axis.horizontal,
              itemBuilder: (_, index) => Container(
                height: MediaQuery.of(context).size.width / 3,
                width: MediaQuery.of(context).size.width / 3,
                decoration: BoxDecoration(
                  image:  DecorationImage(
                    image: NetworkImage(
                      image[index],
                    )
                  ),
                  shape: BoxShape.circle
                ),
              ),
              itemCount: image.length,
            ),
          ),
          Text(
            title[0],
            style: const TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 20,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          Text(
            subtitle[0],
            style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
                color: Colors.deepOrange),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 15),

          SizedBox(
            height: 10,
            child: Center(
              child: ListView.separated(
                shrinkWrap: true,
                scrollDirection: Axis.horizontal,
                itemBuilder: (_, index) => Container(
                  height: 8,
                  width: 8,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: index == 0 ? Colors.deepOrange : Colors.grey),
                ),
                itemCount: 4,
                separatorBuilder: (BuildContext context, int index) =>
                    const SizedBox(width: 5),
              ),
            ),
          ),
          const SizedBox(height: 20),
          ...List.generate(
              2,
              (index) => Container(
                    margin: const EdgeInsets.only(bottom: 20),
                    padding: const EdgeInsets.symmetric(horizontal: 25),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          titleDetails[index],
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          contentDetails[index],
                          style: const TextStyle(color: Colors.grey),
                        )
                      ],
                    ),
                  ))
        ],
      ),
      bottomNavigationBar: Container(
        margin: EdgeInsets.all(25),
        height: 50,
        child: ElevatedButton(
          style: const ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(Colors.deepOrange),
              padding: MaterialStatePropertyAll(EdgeInsets.all(0.0)),
              shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ))),
          onPressed: () {},
          child: const Text('Add to cart'),
        ),
      ),
    );
  }
}
